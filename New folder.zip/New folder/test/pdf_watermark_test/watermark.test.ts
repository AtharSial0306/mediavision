import * as chai from 'chai';
import chaiExclude from 'chai-exclude';
chai.use(chaiExclude);
import 'mocha';

import {createPdf} from "../../src/services/watermark/createPDF";
/**
 * TODO: check
 * https://github.com/foliojs/pdfkit/blob/master/lib/mixins/color.js#L109-L144
 *
 */



describe('Add watermark to pdf', async () => {
  it('create pdf with library', async () => {

    const modes = [
          // 'Normal',
          // 'Multiply',
          // 'Screen',
          // 'Overlay',
          // 'Darken',
          // 'Lighten',
          // 'ColorDodge',
          // 'ColorBurn',
          'HardLight',
          // 'SoftLight',
          // 'Difference',
          // 'Exclusion',
    ]

        // await createPdf('export-transparent' + 'Normal', 'Normal');
        await createPdf('arkitekt-test', 'Normal');
  });

});
