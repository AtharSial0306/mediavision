
let XLSX = require("xlsx")
let path = require("path")
var request = require('request');

const filePath = path.join(__dirname, '../excel_files/positive/bar_example.xlsx');
const wb = XLSX.readFile(filePath);
const wbout = XLSX.write(wb, { bookType:'xlsx', bookSST:false, type:'base64' });

console.log(wbout)
request.post('http://localhost:9001/graphs/bar',{
    json:{
        file: { title: 'Bar Example', xLabel: 'Years', yLabel: 'Percentage', xType:"year",},
        
        data: wbout,
        mediaType:"video",
        category: '5de2afa766055e4a60e89c7e',
        country:"5de26e1153ac15495410f7b3"
    }      
})