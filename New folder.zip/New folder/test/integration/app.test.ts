import * as chai from 'chai';
import chaiExclude from 'chai-exclude';
chai.use(chaiExclude);
import XLSX from 'xlsx';
import path from 'path';
import 'mocha';
import {agent as request} from 'supertest';

import app from '../../src/app';
import {  BarGraph } from '../../src/models/graph.model';

const EXCLUDED_FIELDS = ['__v', '_id']

describe('Getting Graphs through app', async () => {

  // it('GIVEN: saved Line Graph, WHEN: GET /graphs/line/:id, THEN: expect LineGraph JSON', async () => {
  //   const lineGraphJSON = {
  //     title: 'LineGraph',
  //     xLabel: 'xLabel',
  //     xValues: [1, 2, 3],
  //     yLabel: 'yLabel',
  //     lines: [{label: 'line 1', yValues: [4, 5, 6]}]
  //   };
  //   const lineGraph = await new LineGraph(lineGraphJSON).save(); 
    
  //   const res = await request(app).get(`/graphs/line/${lineGraph._id}`);

  //   chai.expect(res.status).to.equal(200);
  //   chai.expect(res.body).to.be.a.instanceof(Array).and.have.length(1);
  //   chai.expect(res.body[0]).excludingEvery(EXCLUDED_FIELDS).to.deep.equal(lineGraphJSON);
  // });

  it('GIVEN: saved Bar Graph, WHEN: GET /graphs/bar/:id, THEN: expect BarGraph JSON', async () => {
    const barGraphJSON = {
      title: 'BarGraph',
      xLabel: 'xLabel',
      xValues: [1, 2, 3],
      yLabel: 'yLabel',
      bars: [{label: 'bar 1', yValues: [4, 5, 6]}]
    };
    const barGraph = await new BarGraph(barGraphJSON).save();
    
    const res = await request(app).get(`/graphs/bar/${barGraph._id}`);

    chai.expect(res.status).to.equal(200);
    chai.expect(res.body).to.be.a.instanceof(Array).and.have.length(1);
    chai.expect(res.body[0]).excludingEvery(EXCLUDED_FIELDS).to.deep.equal(barGraphJSON);
  });

});

describe('Creating Graphs through app', async () => {

  // it('GIVEN: line_example.xlsx, WHEN: POST base64, THEN: expect LineGraph JSON', async () => {
  //   const filePath = path.join(__dirname, '../excel_files/line_example.xlsx');
  //   const wb = XLSX.readFile(filePath);
  //   const wbout = XLSX.write(wb, { bookType:'xlsx', bookSST:false, type:'base64' });

  //   const res = await request(app).post('/graphs/line').send({
  //     file: { title: 'Line Example', xLabel: 'Years', yLabel: 'Percentage'},
  //     data: wbout
  //   });

  //   chai.expect(res.status).to.equal(200);
  //   chai.expect(res.body).not.to.be.empty;
  //   console.log(res.body);
  // });

  it('GIVEN: bar_example.xlsx, WHEN: POST base64, THEN: expect BarGraph JSON', async () => {
    const filePath = path.join(__dirname, '../excel_files/bar_example.xlsx');
    const wb = XLSX.readFile(filePath);
    const wbout = XLSX.write(wb, { bookType:'xlsx', bookSST:false, type:'base64' });

    const res = await request(app).post('/graphs/bar').send({
      file: { title: 'Bar Example', xLabel: 'Years', yLabel: 'Percentage'},
      data: wbout
    });

    chai.expect(res.status).to.equal(200);
    chai.expect(res.body).not.to.be.empty;
    console.log(res.body);
  });

  it('GIVEN: pie_example.xlsx, WHEN: POST base64, THEN: expect PieGraph JSON', async () => {
    const filePath = path.join(__dirname, '../excel_files/pie_example.xlsx');
    const wb = XLSX.readFile(filePath);
    const wbout = XLSX.write(wb, { bookType:'xlsx', bookSST:false, type:'base64' });

    const res = await request(app).post('/graphs/pie').send({
      file: { title: 'Pie Example', categoryLabel: 'Gender'},
      data: wbout
    });

    chai.expect(res.status).to.equal(200);
    chai.expect(res.body).not.to.be.empty;
    console.log(res.body);
  });

  it('GIVEN: waterfall_example.xlsx, WHEN: POST base64, THEN: expect WaterFallGraph JSON', async () => {
    const filePath = path.join(__dirname, '../excel_files/waterfall_example.xlsx');
    const wb = XLSX.readFile(filePath);
    const wbout = XLSX.write(wb, { bookType:'xlsx', bookSST:false, type:'base64' });

    const res = await request(app).post('/graphs/waterfall').send({
      file: { title: 'Waterfall Example', xLabel: 'Years'},
      data: wbout
    });

    chai.expect(res.status).to.equal(200);
    chai.expect(res.body).not.to.be.empty;
    console.log(res.body);
  });

});
