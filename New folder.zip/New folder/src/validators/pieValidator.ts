import {Request, Response} from "express";
const Joi = require('joi');

export function pieValidator(req: Request, res: Response, next: any) {
    const schema = Joi.object({
        // file: Joi.string().min(2).required(),
        file: Joi.object()
            .keys({
                title: Joi.string().max(26).required(),
                xType: Joi.string().optional().allow(''),
                xLabel: Joi.number().integer().optional().allow(null),
                yLabel: Joi.number().integer().optional().allow(null),
                categoryLabel: Joi.string().optional().allow(''),
                isPercentage: Joi.bool()
            }),
        data: Joi.string().optional().allow(null),
        mediaType: Joi.string().optional().allow(''),
        category: Joi.string().optional().allow(''),
        country: Joi.string().required(),
        hasDecimals: Joi.number().optional().allow(null),
    })

    const {error, value} = schema.validate(req.body);

    if (error) {
        return res.status(422).send(error);
    }

    return next()
}
