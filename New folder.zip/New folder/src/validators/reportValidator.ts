import {Request, Response} from "express";
const Joi = require('joi');

export function reportValidator(req: Request, res: Response, next: any) {
    const schema = Joi.object({
        report_name: Joi.string().required(),
        report_group: Joi.string().optional().allow(''),
        publishing_date: Joi.date().optional().allow(null),
        period: Joi.string().optional().allow(''),
        file_path: Joi.string().optional().allow(''),
        file_name: Joi.string(),
        id: Joi.string().optional().allow(null),
        user_id: Joi.string().optional().allow(null),
    })

    const {error, value} = schema.validate(req.body);

    if (error) {
        return res.status(422).send(error);
    }

    return next()
}
