import {Request, Response} from "express";
const Joi = require('joi');

export function categoryValidator(req: Request, res: Response, next: any) {
    const schema = Joi.object({
        _id: Joi.optional(),
        __v: Joi.optional(),
        absRel: Joi.optional(),
        individual: Joi.optional(),
        showCombinedAlternative: Joi.optional(),
        title: Joi.string()
            .min(2)
            .required(),
        footnote: Joi.string()
            .optional().allow(''),
        barType: Joi.string()
            .min(2)
            .required(),
        headCategory: Joi.string()
            .optional()
            .min(2),
        showCombined: Joi.bool()
            .optional(),
        subtitle: Joi.string()
            .optional().allow(''),
        order: Joi.number().integer()
            .optional().allow(''),
    })

    const {error, value} = schema.validate(req.body);

    if (error) {
        return res.status(422).send(error);
    }

    return next()
}
