import XLSX from 'xlsx';

import { BarGraph, PieGraph, WaterfallGraph } from '../models/graph.model';


function validateWorkbook(workbook: XLSX.WorkBook) {
    if (workbook.SheetNames.length != 1) {
        throw new Error('Workbook must have only 1 Sheet');
    }
    if (!workbook.Sheets) {
        throw new Error('Workbook must have Sheets');
    }
}

function transpose(matrix: (string | number)[][]) {
  return matrix[0].map((_, i) => matrix.map(row => row[i]));
}

function zip(a: string[], b: number[]) {
  return a.map((e, i) => [e, b[i]]);
}


function instanceOfWorkBook(object: any): object is XLSX.WorkBook {
  return object.Sheets;
}


export function excelToBarGraph(workbook: XLSX.WorkBook | XLSX.Sheet, title: String, xLabel: String, yLabel: String, categoryId:String, countryId:String, xType:String, mediaType:String, isPercentage:Boolean, hasDecimals:Number) {
  var bars:any;
  var xValues:any;

  if(workbook){
    var matrix: (string | number)[][];
  if(instanceOfWorkBook(workbook)){
    validateWorkbook(workbook);
    matrix= XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]], {header: 1});
  } else{
    matrix = XLSX.utils.sheet_to_json(workbook, {header:1})
  }
  
  
  
  matrix = matrix.filter((matr) => matr.length > 0)
  xValues = matrix[0].slice(1);
  xValues = xValues.filter((x) => x !== null && x !== "")
  switch(xType.toLowerCase()){
    case "year":
    xValues = xValues.map((year) => {
      return new Date(Number(year), 0,1,18,0,0,0).toISOString()
    })
    break;
    case "quarter":
    xValues = xValues.map((quarter) => {
      let splittedString = String(quarter).split(" ");
      let month = 0;
      switch(splittedString[0].toLowerCase()){
        case "q1":
        month = 0;
        break;
        case "q2":
        month = 3;
        break;
        case "q3":
        month = 6
        break;
        case "q4":
        month = 9;
        break;
      }

      let year = splittedString[1]
      
      return new Date(Number(year), month,1,18,0,0,0).toISOString()
    })
    break;
    case "other":
    break;
  }

  bars = matrix.slice(1).filter((x) => x!==null && x+"" !== "").map((row) => {
    const label = row[0];
    const yValues = row.slice(1);
    return {label: label, yValues: yValues};
  });
  }
  

  const barGraph = {isPercentage:isPercentage, title: title, xLabel: xLabel, xValues: xValues, yLabel: yLabel, bars: bars, category: categoryId, country: countryId, xType:xType, mediaType:mediaType, hasDecimals:hasDecimals};

  return  new BarGraph(barGraph);

}

export function excelToPieGraph(workbook: XLSX.WorkBook | XLSX.Sheet , title: String, categoryLabel: String, categoryId:String, countryId:String, mediaType:String, xType:String, hasDecimals:Number) {
  var pies:any;

  if(workbook){

  var matrix: (string | number)[][];

  if(workbook && instanceOfWorkBook(workbook)){
    validateWorkbook(workbook);
     matrix = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]], {header: 1});
  } else{
    matrix = XLSX.utils.sheet_to_json(workbook, {header:1})

  }
  

  matrix = matrix.filter((matr) => matr.length > 0)
  // For transpose to work
  matrix[0][0] = 0;
  
    const matrixT = transpose(matrix);
  const categories = matrixT[0].slice(1) as string[];
  pies =matrixT.slice(1).map((row) => {
    let label = row[0];
    if(xType === "year"){
      label = new Date(Number(label), 0,1,18,0,0,0).toISOString()
    } else if(xType === "quarter"){
      let splittedString = String(label).split(" ");
      let month = 0;
      switch(splittedString[0].toLowerCase()){
        case "q1":
        month = 0;
        break;
        case "q2":
        month = 3;
        break;
        case "q3":
        month = 6
        break;
        case "q4":
        month = 9;
        break;
      }

      let year = splittedString[1]
      
      label = new Date(Number(year), month,1,18,0,0,0).toISOString()
    }

    const values = row.slice(1) as number[];
    const zipped = zip(categories, values) as [string, number][];
    return {label: label, pie: new Map(zipped)};
  });
  }
  
  
  const pieGraph = {title: title, categoryLabel: categoryLabel, pies: pies, category:categoryId, country:countryId, mediaType:mediaType, xType:xType, hasDecimals:hasDecimals};

  return new PieGraph(pieGraph);
}

export function excelToWaterfallGraph(workbook: XLSX.WorkBook, title: String, xLabel: String, categoryId:String, countryId:String, mediaType:String) {
  validateWorkbook(workbook);

  var matrix: (string | number)[][] = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]], {header: 1});
  matrix = matrix.filter((matr) => matr.length > 0)
  const xValues = matrix[0].slice(1);
  // For transpose to work
  matrix[0][0] = 0;
  const matrixT = transpose(matrix);
  const seqLabels = matrixT[0].slice(1);
  const sequences = matrixT.slice(1).map(row => row.slice(1));
  const waterfallGraph = {title: title, seqLabels: seqLabels, xLabel: xLabel, xValues: xValues, sequences: sequences, category:categoryId, country:countryId, mediaType:mediaType};

  return new WaterfallGraph(waterfallGraph);
}
