import {
  Request,
  Response
} from 'express';
import {Report, Users} from '../models/graph.model';
import * as fs from "fs";
import {createPermissionsFile} from "./reportPermissions";

export interface ReportInterface {
  report_name: string;
  report_group?: string;
  publishing_date?: string;
  period?: string;
  file_name?: string;
  file_path?: string;
  _id?: Object;
  file: string;
  report_access: [
    {
      report_name: string,
      report_id: string
    }
  ]
}


export class ReportsService {

  public async getReports(req: Request, res: Response) {
    const reports = await Report.find({}).sort({'publishing_date': -1});
    res.json(reports);
  }

  public async getUserReports(req: Request, res: Response) {
    const user: any = await Users.findOne({auth_key: req.params.id});
    const reportIds = user?.report_access.map( report => report.report_id)
    const reports = await Report.find({_id: {$in: reportIds}})


    res.json(reports)
  }

  public async getImage(req: Request, res: Response) {
    const shortPath = 'uploads/' + req.params.imageName;
    if(fs.existsSync(shortPath)){

      res.download(shortPath)
    } else {
      res.json(null)
    }
  }


  public async createReport(req: Request, res: Response) {
    let data = {'status' : 'done'};
    const report: any = await Report.create(req.body)

    if (report) {
      await Users.updateOne({auth_key: req.body.user_id}, {$push: {
          report_access: {
            report_id: report._id,
            report_name: report.report_name,
          }
        }})

      await createPermissionsFile()
      res.json(data);
    }
  }



  public async updateReports(req: Request, res: Response) {
    let data = {'status' : 'done'};
    const report = await Report.updateOne({_id: req.body.id}, req.body);

    if (report) {
      await createPermissionsFile()
      res.json(data);
    }
  }


  public async deleteReports(req: Request, res: Response) {
    let data = {'status' : 'done'};
    const report = await Report.deleteOne({_id: req.body.id})

    if (report) {
      await createPermissionsFile()
      res.json(data);
    }
  }


}




