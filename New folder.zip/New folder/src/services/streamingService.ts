import { Request, Response } from "express";
import { Streaming, UserRole } from "../models/graph.model";

import { Document, Types } from "mongoose";

export class StreamingClass {
  public async createStreaming(req: Request, res: Response) {
    const data = req.body;
    let stream = new Streaming(data);
    stream.save((error: Error, st: Document) => {
      res.json(st);
    });
  }

  public async updateStreaming(req: Request, res: Response) {
    let update = JSON.parse(JSON.stringify(req.body));
    delete update._id;
    Streaming.update(
      {
        _id: req.body._id,
      },
      update,
      {},
      (err, doc) => {
        if (!err) {
          res.json(doc);
        } else {
          throw new Error(err.message || err.toString());
        }
      }
    );
  }

  public async getStreamingAdmin(req: Request, res: Response) {
    Streaming.find()
      .lean()
      .then((r) => {
        res.json(r);
      });
  }
  public async myRoute(req: Request, res: Response) {
    res.status(200).json({ message: "Good got to my route" });
  }
  public async getStreaming(req: any, res: Response) {
    let roles = [];
    UserRole.find({
      title: {
        $in: req.user["https://mediavision.se/roles"].map((role) => role.name),
      },
    })
      .lean()
      .then((obj) => {
        roles = obj.map((a) => a._id.toString());
        return Streaming.find().lean();
      })
      .then((r) => {
        res.json(
          r.filter((stream) => {
            return stream.roles.some((f) => {
              return roles.includes(f);
            });
          })
        );
      });
  }

  public async getStream(req: Request, res: Response) {
    console.log(req.query.id);
    Streaming.findById(new Types.ObjectId(String(req.query.id))).then((r) => {
      res.json(r);
    });
  }

  public async deleteStream(req: Request, res: Response) {
    Streaming.findByIdAndDelete(new Types.ObjectId(String(req.query.id))).then(
      (r) => {
        res.json(r);
      }
    );
  }
}
