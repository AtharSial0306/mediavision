let obj = {
    "graphs": [
        {
            "xValues": [
                "q1 2010",
                "q2 2010",
                "q3 2010",
                "q4 2010",
                "q1 2011",
                "q2 2011",
                "q3 2011",
                "q4 2011",
                "q1 2012",
                "q2 2012",
                "q3 2012"
            ],
            "_id": "5de26ddc53ac15495410f7ab",
            "title": "Bar Example",
            "xLabel": "Years",
            "bars": [
                {
                    "yValues": [
                        0.2,
                        0.23,
                        0.28,
                        0.31,
                        0.36,
                        0.42,
                        0.5,
                        0.53,
                        0.59,
                        0.64,
                        0.7
                    ],
                    "_id": "5de26ddc53ac15495410f7b1",
                    "label": "Total population"
                },
                {
                    "yValues": [
                        0.6,
                        0.62,
                        0.65,
                        0.68,
                        0.7,
                        0.73,
                        0.8,
                        0.82,
                        0.86,
                        0.9,
                        0.92
                    ],
                    "_id": "5de26ddc53ac15495410f7b0",
                    "label": "0-19 y/o"
                },
                {
                    "yValues": [
                        0.45,
                        0.5175,
                        0.6,
                        0.62,
                        0.65,
                        0.68,
                        0.7,
                        0.73,
                        0.8,
                        0.82,
                        0.86
                    ],
                    "_id": "5de26ddc53ac15495410f7af",
                    "label": "20-39 y/o"
                },
                {
                    "yValues": [
                        0.3,
                        0.345,
                        0.39,
                        0.42,
                        0.45,
                        0.53,
                        0.6,
                        0.62,
                        0.65,
                        0.68,
                        0.7
                    ],
                    "_id": "5de26ddc53ac15495410f7ae",
                    "label": "40-59 y/o"
                },
                {
                    "yValues": [
                        0.12,
                        0.13799999999999998,
                        0.18,
                        0.19928571428571426,
                        0.3,
                        0.35000000000000003,
                        0.39,
                        0.42,
                        0.45,
                        0.488135593220339,
                        0.6
                    ],
                    "_id": "5de26ddc53ac15495410f7ad",
                    "label": "60-79 y/o"
                },
                {
                    "yValues": [
                        0.02,
                        0.06,
                        0.08,
                        0.12,
                        0.1393548387096774,
                        0.18,
                        0.21428571428571427,
                        0.3,
                        0.3339622641509434,
                        0.39,
                        0.4265625
                    ],
                    "_id": "5de26ddc53ac15495410f7ac",
                    "label": "80-99 y/o"
                }
            ],
            "category": {
                "_id": "5de27b15f22b32580cb2e0fa",
                "title": "kategori",
                "barType": "barGraph",
                "headCategory": "5de268316c994e5e40eb8732",
                "__v": 0
            },
            "country": {
                "_id": "5de26d36cf9c025e18d78ac5",
                "title": "sweden",
                "__v": 0
            },
            "xType": "year",
            "mediaType": "text",
            "__v": 0
        }
    ],
    "countries": {
        "5de26d36cf9c025e18d78ac5": {
            "title": "sweden",
            "_id": "5de26d36cf9c025e18d78ac5"
        }
    }
}

let role = [{
    "_id": "5de27b15f22b32580cb2e0f9",
    "title": "FIRST",
    "categories": [
        {
            "_id": "5de27b15f22b32580cb2e0fa",
            "category": "5de2687e6c994e5e40eb8733",
            "countries": [
                {
                    "_id": "5de26d36cf9c025e18d78ac5",
                    "country": "5de26e1553ac15495410f7b4",
                    "video": true,
                    "text": true,
                    "sound": false
                },
                {
                    "_id": "5de27b15f22b32580cb2e0fb",
                    "country": "5de26e1153ac15495410f7b3",
                    "video": false,
                    "text": false,
                    "sound": false
                }
            ]
        }
    ],
    "__v": 0
}]


role = role.map((role) => {
    let categories = {}
    role.categories.map((category) => {
        
        let countries = {} 
        category.countries.map((country) => {
            countries[country._id] = country
        })
        category.countries = countries
       categories[category._id] = category
    });
    role.categories = categories

    return role
})


function checkGraphWithRole(role, graph){
    return role.categories[graph.category._id] 
        && role.categories[graph.category._id].countries[graph.country._id] 
        && role.categories[graph.category._id].countries[graph.country._id][graph.mediaType]
}

obj.graphs.filter((graph) => role.some((role) => checkGraphWithRole(role, graph)))


