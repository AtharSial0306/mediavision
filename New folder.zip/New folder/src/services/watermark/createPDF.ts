import {BlendMode, degrees, PDFDocument, rgb, RotationTypes, StandardFonts} from 'pdf-lib'
import * as fs from "fs";
import fontkit from '@pdf-lib/fontkit'
import {
    PDFRawStream,
    decodePDFRawStream,
    arrayAsString,
    PDFRef,
    PDFObject,
    PDFPage,
} from 'pdf-lib';

const drawTextsOnPdf = async (pdfDoc, mode) => {
    const fontSize = 60
    const font = await pdfDoc.embedFont(StandardFonts.TimesRoman)
    const fontPath = './src/services/watermark/font/Avenir-Medium/Avenir-Medium.ttf';
    const fontBytes = fs.readFileSync(fontPath, {
        encoding: null
    });

    pdfDoc.registerFontkit(fontkit)
    const customFont = await pdfDoc.embedFont(fontBytes)

    // const customFont = font;
    for (let pageIndex = 0; pageIndex < pdfDoc.getPageCount(); pageIndex++) {
        if (pageIndex === 0) {
            continue;
        }
        const page = pdfDoc.getPage(pageIndex)
        const { width, height } = page.getSize()
        const rot = RotationTypes.Degrees
        const blendMode = mode ? mode : BlendMode.Normal
        const opacity = 1
        page.drawText('For Kalle Kula', {
            x: width / 3 + 1,
            y: height / 4 + 70, // 450 / 2 + 100
            size: fontSize,
            font: customFont,
            color: rgb(0.6, 0.7,0.8),
            rotate: degrees(30),
            opacity: opacity,
            blendMode: blendMode,
        })

        page.drawText('Företag A', {
            x: width / 3 + 1,
            y: height / 4 + 140, // 450 / 2 + 100
            size: fontSize,
            font: customFont,
            color: rgb(0.6, 0.7,0.8),

            rotate: degrees(30),
            opacity: opacity,
            blendMode: blendMode,
        })

        page.drawText('Internal use only', {
            x: width / 3 + 1,
            y: 500 + 1, // 450 / 2 + 100
            size: fontSize,
            font: customFont,
            color: rgb(0.6, 0.7,0.8),

            rotate: degrees(30),
            opacity: opacity,
            blendMode: blendMode,
        })
    }
}

const drawImageOnPdf = async (pdfDoc) => {
    const imagePath = './test/pdf_watermark_test/checked.png';
    const jpgImage = fs.readFileSync(imagePath, {
        encoding: null
    });

    // const jpgImage2 = await pdfDoc.embedJpg(jpgImage)
    const jpgImage2 = await pdfDoc.embedPng(jpgImage)
    const jpgDims = jpgImage2.scale(0.5)
    const firstPage = pdfDoc.getPage(1)

    firstPage.drawImage(jpgImage2, {
        x: 200 - jpgDims.width / 2,
        y: 200 - jpgDims.height / 2 + 250,
        width: jpgDims.width,
        height: jpgDims.height,
        opacity: 0.4,
    })
}

const drawTextOnPage = async (pdfDoc, page, pageIndex) => {
    const { width, height } = page.getSize()
    const font = await pdfDoc.embedFont(StandardFonts.TimesRoman)
    const fontPath = './src/services/watermark/font/Avenir-Medium/Avenir-Medium.ttf';
    const fontBytes = fs.readFileSync(fontPath, {
        encoding: null
    });
    pdfDoc.registerFontkit(fontkit)
    // await drawTextsOnPdf(pdfDoc, 'Normal')
    const customFont = await pdfDoc.embedFont(fontBytes)



    const blendMode = BlendMode.Normal
    const opacity = 1
    const fontSize = 60
    page.drawText('For Arkitektkopia', {
        x: width / 3 + 1,
        y: height / 4 + 70, // 450 / 2 + 100
        size: fontSize,
        font: customFont,
        color: rgb(0.6, 0.7,0.8),
        // rotate: degrees(30),
        opacity: opacity,
        blendMode: blendMode,
    })
    page.drawText('Page ' + pageIndex, {
        x: width / 3 + 1,
        y: height / 4 + 140, // 450 / 2 + 100
        size: fontSize,
        font: customFont,
        color: rgb(0.6, 0.7,0.8),
        // rotate: degrees(30),
        opacity: opacity,
        blendMode: blendMode,
    })

    // page.drawText('Internal use only', {
    //     x: width / 3 + 1,
    //     y: height / 4, // 450 / 2 + 100
    //     size: fontSize,
    //     font: customFont,
    //     color: rgb(0.6, 0.7,0.8),
    //     rotate: degrees(30),
    //     opacity: opacity,
    //     blendMode: blendMode,
    // })
    // await drawImageOnPdf(pdfDoc)
}


const copyPageWithWatermark = async (loadedPDFDoc, pdfDoc, pageIndex) => {
    const pageThatIWantToAdd = await loadedPDFDoc.getPage(pageIndex);
    const { width, height } = pageThatIWantToAdd.getSize()
    let page = pdfDoc.addPage()
    page.setSize(width, height)
    // const pdfEmbeddedPage = await pdfDoc.embedPage(pageThatIWantToAdd)
    const pdfEmbeddedPage = page
    removePageBackground(pdfEmbeddedPage);

    if (pageIndex > 0) {
        await drawTextOnPage(pdfDoc, page, pageIndex)
    }
    // page.setBleedBox(0, 0, 250, 500)
    // page.drawPage(pdfEmbeddedPage, { })
}

const randomBlend = () => {
    const rand = Math.floor(Math.random() * 12);
    const blend = Object.keys(BlendMode)[rand]

    return blend;
}

const pink = rgb(255 / 255, 128 / 255, 191 / 255);

// const whitespace = '[\\0\\t\\n\\f\\r\\ ]+';
const whitespace = '[\\0\\t\\n\\f\\r\\ ]+';
const forwardSlash = '\\/';
const alphanumerics = '\\w+';
const decimal = '\\d+\\.\\d+|\\d+';

// prettier-ignore
const whiteBackgroundOperatorsRegex = new RegExp(
    `${forwardSlash}${alphanumerics}${whitespace}rg${whitespace}` +
    `1${whitespace}1${whitespace}1${whitespace}re${whitespace}` +
    `(?<x1>${decimal})${whitespace}(?<y1>${decimal})${whitespace}m${whitespace}` +
    `(?<x2>${decimal})${whitespace}(?<y2>${decimal})${whitespace}l${whitespace}` +
    `(?<x3>${decimal})${whitespace}(?<y3>${decimal})${whitespace}l${whitespace}` +
    `(?<x4>${decimal})${whitespace}(?<y4>${decimal})${whitespace}l${whitespace}` +
    `h${whitespace}` +
    `f`
);

// const whiteBackgroundOperatorsRegex = new RegExp(
//     // `${forwardSlash}${alphanumerics}${whitespace}cs${whitespace}` +
//     // `1${whitespace}1${whitespace}1${whitespace}sc${whitespace}` +
//     `(?<x1>${decimal})${whitespace}(?<y1>${decimal})${whitespace}m${whitespace}` +
//     `(?<x2>${decimal})${whitespace}(?<y2>${decimal})${whitespace}l${whitespace}` +
//     `(?<x3>${decimal})${whitespace}(?<y3>${decimal})${whitespace}l${whitespace}` +
//     `(?<x4>${decimal})${whitespace}(?<y4>${decimal})${whitespace}l${whitespace}` +
//     `h${whitespace}` +
//     `f`
// );

const almostEqual = (a: string | number, b: string | number, error = 0.1) =>
    Math.abs(Number(a) - Number(b)) <= error;

const tryToDecodeStream = (maybeStream?: PDFObject) => {
    if (maybeStream instanceof PDFRawStream) {
        return arrayAsString(decodePDFRawStream(maybeStream).decode());
    }
    return undefined;
};

const removeWhiteBackground = (
    streamContents: string,
    size: { width: number; height: number },
) => {
    let match = streamContents.match(whiteBackgroundOperatorsRegex);
    while (match) {
        console.log('match')
        const { x1, y1, x2, y2, x3, y3, x4, y4 } = match.groups || {};
        const matchSizeIsWithinSize =
            almostEqual(x1, 0) &&
            almostEqual(y1, size.height, 5) &&
            almostEqual(x2, size.width, 5) &&
            almostEqual(y2, size.height, 5) &&
            almostEqual(x3, size.width, 5) &&
            almostEqual(y3, 0) &&
            almostEqual(x4, 0) &&
            almostEqual(y4, 0);
        if (!matchSizeIsWithinSize) break;
        const targetStart = match.index || 0;
        const targetEnd = targetStart + match[0].length;
        streamContents =
            streamContents.substring(0, targetStart) +
            streamContents.substring(targetEnd, streamContents.length);
        match = streamContents.match(whiteBackgroundOperatorsRegex);
    }
    return streamContents;
};

const removePageBackground = (page: PDFPage) => {
    if (page.node) {
        const { Contents } = page.node.normalizedEntries();
        if (!Contents) return;
        Contents.asArray().forEach((streamRef) => {
            if (streamRef instanceof PDFRef) {
                const stream = page.doc.context.lookup(streamRef);
                fs.writeFile(`stream.txt`, JSON.stringify(stream), () => {
                    console.log('done')
                })
                const contents = tryToDecodeStream(stream);
                if (contents) {
                    const newContents = removeWhiteBackground(contents, page.getSize());
                    const newStream = page.doc.context.flateStream(newContents);
                    page.doc.context.assign(streamRef, newStream);
                }
            }
        });
    }
};

export const createPdf = async (baseName = 'export', mode) => {
    const existingPdfBytes = fs.readFileSync('imports/dummy-analysis.pdf',  null).buffer;
    const loadedPDFDoc = await PDFDocument.load(existingPdfBytes)
    const pdfDoc= await PDFDocument.create()

    for (let pageIndex =0; pageIndex < loadedPDFDoc.getPageCount(); pageIndex++) {
        await copyPageWithWatermark(loadedPDFDoc, pdfDoc, pageIndex)
    }

    const pdfBytes = await pdfDoc.save()
    const date = new Date;
    const shortDate = date.toISOString().split('T')[0]

    fs.writeFile(`exports/${baseName}-${shortDate}.pdf`, pdfBytes, err => {
        if (err) {
            console.error(err)
            return
        }
        return {status: 200}
    })

}
