const { PdfReader } = require("pdfreader");


export const createPdfWithPdfReader = async () => {
    // Create a new PDFDocument
    const filePath = 'imports/example.pdf'

    new PdfReader().parseFileItems(filePath, (err, item) => {
        if (err) console.error("error:", err);
        else if (!item) console.warn("end of file");
        else if (item.text) console.log(item.text);
    });




}
