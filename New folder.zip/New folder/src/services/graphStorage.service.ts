import { Request, Response } from "express";
import { Document, Types, ObjectId } from "mongoose";
import XLSX from "xlsx";
var excel = require("excel4node");

import {
  BarGraph,
  Categories,
  Countries,
  UserRole,
  PieGraph,
  WaterfallGraph,
} from "../models/graph.model";
import {
  excelToBarGraph,
  excelToPieGraph,
  excelToWaterfallGraph,
} from "../utils/excelConverter";

export class GraphStorage {
  public async getBarGraph(req: Request, res: Response) {
    const id = req.params.id;
    const graph = await BarGraph.find({ _id: id }).populate("country category");
    res.json(graph);
  }

  public async getPieGraph(req: Request, res: Response) {
    const id = req.params.id;
    const graph = await PieGraph.find({ _id: id }).populate("country category");
    res.json(graph);
  }

  public async updateBarData(req: Request, res: Response) {
    if (req.body.data === null) {
      const graph = await BarGraph.findById(new Types.ObjectId(req.body.id))
        .populate("country category")
        .lean();
      graph.hasDecimals = req.body.hasDecimals;
      graph.xLabel = req.body.xLabel;
      graph.yLabel = req.body.yLabel;
      graph.xType = req.body.xType;
      (graph as any).yType = req.body.yType;
      BarGraph.updateOne(
        { _id: req.body.id },
        graph,
        {},
        (err: any, doc: any) => {
          if (!err) {
            res.json(doc);
          } else {
            throw new Error(err.message || err.toString());
          }
        }
      );
    } else {
      const wb = XLSX.read(req.body.data, { type: "base64" });
      const graph = await BarGraph.findById(new Types.ObjectId(req.body.id))
        .populate("country category")
        .lean();
      const newBarGraph = excelToBarGraph(
        wb,
        req.body.title,
        graph.xLabel,
        graph.yLabel,
        graph.category?._id?.toString() || "", // Safe toString with null check
        graph.country?._id?.toString() || "",
        graph.xType,
        graph.mediaType,
        graph.isPercentage,
        graph.hasDecimals
      );
      newBarGraph._id = req.body.id;
      BarGraph.updateOne(
        { _id: req.body.id },
        newBarGraph,
        {},
        (err: any, doc: any) => {
          if (!err) {
            res.json(doc);
          } else {
            throw new Error(err.message || err.toString());
          }
        }
      );
    }
  }

  public saveBarGraph(req: Request, res: Response) {
    var wb: any;
    if (req.body.data) {
      wb = XLSX.read(req.body.data, { type: "base64" });
    }

    const title = req.body.file.title;
    const xLabel = req.body.file.xLabel;
    const xType = req.body.file.xType;
    const yLabel = req.body.file.yLabel;

    const category = req.body.category;
    const country = req.body.country;
    const mediaType = req.body.mediaType;
    const hasDecimals = req.body.hasDecimals;

    const isPercentage = req.body.file.isPercentage;

    const newBarGraph = excelToBarGraph(
      wb,
      title,
      xLabel,
      yLabel,
      category, // Assume string from body; if ObjectId, add .toString()
      country,
      xType,
      mediaType,
      isPercentage,
      hasDecimals
    );
    newBarGraph.save((error: Error, barGraph: Document) => {
      if (error) {
        res.status(400).send(error);
      }
      res.json(barGraph);
    });
  }

  public deleteBarGraph(req: Request, res: Response) {
    BarGraph.deleteOne({ _id: req.query.id }, () => {
      res.json({ success: true });
    });
  }

  public deleteWaterFallGraph(req: Request, res: Response) {
    WaterfallGraph.deleteOne({ _id: req.query.id }, () => {
      res.json({ success: true });
    });
  }

  public deletePieGraph(req: Request, res: Response) {
    PieGraph.deleteOne({ _id: req.query.id }, () => {
      res.json({ success: true });
    });
  }

  public async downloadBulk(req: Request, res: Response) {
    let mediaType = req.body.mediaType;
    let country = req.body.country;
    var workbook = new excel.Workbook();

    let barGraphs = await BarGraph.find({
      mediaType: mediaType,
      country: country,
    }).lean();
    if (barGraphs.length > 0) {
      barGraphs.forEach((sheet: any) => {
        // Use forEach instead of map for side effects
        var worksheet = workbook.addWorksheet(sheet.title);
        var style = workbook.createStyle({
          font: {
            size: 12,
          },
        });
        worksheet
          .cell(1, 1)
          .string(sheet._id + "")
          .style(style);
        sheet.xValues.forEach((xVal: any, i: number) => {
          // forEach for side effects
          // Coercion moved outside if (available for all branches)
          let xValPrimitive: string | number | Date;
          if (Array.isArray(xVal)) {
            // If array, take first non-null item and coerce
            const firstItem = xVal.find((item: any) => item != null);
            xValPrimitive = firstItem
              ? typeof firstItem === "string" || typeof firstItem === "number"
                ? firstItem
                : new Date(firstItem).toISOString()
              : new Date().toISOString();
          } else if (typeof xVal === "object" && xVal !== null) {
            xValPrimitive = xVal.toString(); // Object to string
          } else {
            xValPrimitive = xVal || new Date().toISOString(); // Fallback
          }

          if (sheet.xType === "quarter") {
            let date = new Date(String(xValPrimitive)); // Safe string coerce
            switch (date.getMonth()) {
              case 0:
                worksheet
                  .cell(1, i + 2)
                  .string("q1 " + date.getFullYear())
                  .style(style);
                break;
              case 3:
                worksheet
                  .cell(1, i + 2)
                  .string("q2 " + date.getFullYear())
                  .style(style);
                break;
              case 6:
                worksheet
                  .cell(1, i + 2)
                  .string("q3 " + date.getFullYear())
                  .style(style);
                break;
              case 9:
                worksheet
                  .cell(1, i + 2)
                  .string("q4 " + date.getFullYear())
                  .style(style);
                break;
              default:
                worksheet
                  .cell(1, i + 2)
                  .string("q1 " + date.getFullYear())
                  .style(style);
                break;
            }
          } else if (sheet.xType === "year") {
            let date = new Date(String(xValPrimitive)); // Now available; safe coerce
            worksheet
              .cell(1, i + 2)
              .string(date.getFullYear() + "")
              .style(style);
          } else {
            worksheet
              .cell(1, i + 2)
              .string(String(xValPrimitive)) // Safe string
              .style(style);
          }
        });

        sheet.bars.forEach((bar: any, j: number) => {
          // forEach
          worksheet
            .cell(j + 2, 1)
            .string(bar.label + "")
            .style(style);
          bar.yValues.forEach((yVal: any, k: number) => {
            worksheet
              .cell(j + 2, k + 2)
              .number(Number(yVal))
              .style(style);
          });
        });
      });
    }

    let pieGraphs = await PieGraph.find({
      mediaType: mediaType,
      country: country,
    }).lean();

    pieGraphs.forEach((piegraph: any) => {
      // forEach
      var worksheet = workbook.addWorksheet(piegraph.title);
      var style = workbook.createStyle({
        font: {
          size: 12,
        },
      });
      worksheet
        .cell(1, 1)
        .string(piegraph._id + "")
        .style(style);

      piegraph.pies.forEach((pie: any, j: number) => {
        // forEach
        console.log(pie);
        if (pie.pie) {
          Object.keys(pie.pie).forEach((lab: string, z: number) => {
            console.log(lab, z, pie.pie[lab]);
            worksheet
              .cell(z + 2, 1)
              .string(lab + "")
              .style(style);
            worksheet
              .cell(z + 2, j + 2)
              .number(Number(pie.pie[lab]))
              .style(style);
          });
        }

        if (piegraph.xType === "quarter") {
          let date = new Date(String(pie.label || "")); // Safe string coerce (fixes line ~191)
          switch (date.getMonth()) {
            case 0:
              worksheet
                .cell(1, j + 2)
                .string("q1 " + date.getFullYear())
                .style(style);
              break;
            case 3:
              worksheet
                .cell(1, j + 2)
                .string("q2 " + date.getFullYear())
                .style(style);
              break;
            case 6:
              worksheet
                .cell(1, j + 2)
                .string("q3 " + date.getFullYear())
                .style(style);
              break;
            case 9:
              worksheet
                .cell(1, j + 2)
                .string("q4 " + date.getFullYear())
                .style(style);
              break;
            default:
              worksheet
                .cell(1, j + 2)
                .string("q1 " + date.getFullYear())
                .style(style);
              break;
          }
        } else if (piegraph.xType === "year") {
          let date = new Date(String(pie.label || "")); // Safe string coerce
          worksheet
            .cell(1, j + 2)
            .string(date.getFullYear() + "")
            .style(style);
        } else {
          worksheet
            .cell(1, j + 2)
            .string(String(pie.label || "")) // Safe string
            .style(style);
        }
      });
    });
    console.log(pieGraphs, barGraphs);

    workbook.write("Excel.xlsx", res);
  }

  public async updateBulk(req: Request, res: Response) {
    const wb = XLSX.read(req.body.data, { type: "base64" });
    let dicts = Object.keys(wb.Sheets);
    // Changed from map to for...of for proper async/await (avoids Promise<void>[])
    for (const dict of dicts) {
      let id = (wb.Sheets[dict] as any)["A1"]["v"]; // Type assertion for wb.Sheets

      const graph = await BarGraph.findById(new Types.ObjectId(id))
        .populate("country category")
        .lean();
      if (graph) {
        const newBarGraph = excelToBarGraph(
          wb.Sheets[dict] as any, // Assertion
          req.body.title,
          graph.xLabel,
          graph.yLabel,
          graph.category?._id?.toString() || "", // Safe toString
          graph.country?._id?.toString() || "",
          graph.xType,
          graph.mediaType,
          graph.isPercentage,
          graph.hasDecimals
        );
        newBarGraph._id = id;
        BarGraph.updateOne(
          { _id: id },
          newBarGraph,
          {},
          (err: any, doc: any) => {
            if (!err) {
              console.log("success", id);
            }
          }
        );
      } else {
        const graph = await PieGraph.findById(new Types.ObjectId(id))
          .populate("country category")
          .lean();
        const newPieGraph = excelToPieGraph(
          wb.Sheets[dict] as any,
          graph.title,
          graph.categoryLabel,
          graph.category?._id?.toString() || "", // Safe
          graph.country?._id?.toString() || "",
          graph.mediaType,
          graph.xType,
          graph.hasDecimals
        );
        newPieGraph._id = id;

        PieGraph.updateOne(
          { _id: id },
          newPieGraph,
          {},
          (err: any, doc: any) => {
            if (!err) {
              console.log("success", id);
            }
          }
        );
      }
    }

    res.send({ ok: "ok" });
  }

  public async updateBulkPie(req: Request, res: Response) {
    const wb = XLSX.read(req.body.data, { type: "base64" });
    let dicts = Object.keys(wb.Sheets);
    // Changed to for...of for async
    for (const dict of dicts) {
      let id = (wb.Sheets[dict] as any)["A1"]["v"];

      const graph = await PieGraph.findById(new Types.ObjectId(id))
        .populate("country category")
        .lean();
      const newPieGraph = excelToPieGraph(
        wb, // Full wb, as per original
        graph.title,
        graph.categoryLabel,
        graph.category?._id?.toString() || "",
        graph.country?._id?.toString() || "",
        graph.mediaType,
        graph.xType,
        graph.hasDecimals
      );
      newPieGraph._id = id;

      PieGraph.updateOne({ _id: id }, newPieGraph, {}, (err: any, doc: any) => {
        if (!err) {
          console.log("success", id);
        }
      });
    }

    res.send({ ok: "ok" });
  }

  public savePieGraph(req: Request, res: Response) {
    var wb: any;
    if (req.body.data) {
      wb = XLSX.read(req.body.data, { type: "base64" });
    }

    const title = req.body.file.title;
    const categoryLabel = req.body.file.categoryLabel;
    const xType = req.body.file.xType;

    const category = req.body.category;
    const country = req.body.country;
    const mediaType = req.body.mediaType;
    const hasDecimals = req.body.hasDecimals;

    const newPieGraph = excelToPieGraph(
      wb,
      title,
      categoryLabel,
      category, // Assume string; if ObjectId, add .toString()
      country,
      mediaType,
      xType,
      hasDecimals
    );

    newPieGraph.save((error: Error, pieGraph: Document) => {
      if (error) {
        res.status(400).send(error);
      }
      res.json(pieGraph);
    });
  }

  public saveWaterfallGraph(req: Request, res: Response) {
    const wb = XLSX.read(req.body.data, { type: "base64" });

    const title = req.body.file.title;
    const xLabel = req.body.file.xLabel;

    const category = req.body.category;
    const country = req.body.country;
    const mediaType = req.body.mediaType;

    const newWaterfallGraph = excelToWaterfallGraph(
      wb,
      title,
      xLabel,
      category, // Assume string
      country,
      mediaType
    );
    newWaterfallGraph.save((error: Error, waterfallGraph: Document) => {
      if (error) {
        res.status(400).send(error);
      }

      res.json(waterfallGraph);
    });
  }
}
