import { Request, Response } from "express";
import { Document, Types, ObjectId } from "mongoose";

import {
  BarGraph,
  Categories,
  Countries,
  UserRole,
  PieGraph,
  WaterfallGraph,
  HeadCategories,
  UserUserRole,
  TopHeadCategories,
} from "../models/graph.model";

export interface IHash {
  [details: string]: string;
}

function authorizeGraphs(graphs: any[], roles: any[]) {
  // Type parameter directly
  return UserRole.find({
    title: {
      $in: roles.map((role: any) => role.name),
    },
  })
    .lean()
    .then((roles: any[]) => {
      roles = roles.map((role: any) => {
        let categoriesObj: { [key: string]: any } = {};
        role.categories.forEach((category: any) => {
          let countriesObj: { [key: string]: any } = {};
          category.countries.forEach((country: any) => {
            const countryKey = country.country
              ? country.country.toString()
              : "";
            countriesObj[countryKey] = country;
          });

          const categoryKey = category.category
            ? category.category.toString()
            : "";
          categoriesObj[categoryKey] = category;
        });

        role.categories = Object.values(categoriesObj); // Array conversion
        return role; // Explicit return
      }) as any[]; // Cast to any[] for schema match

      function checkGraphWithRole(role: any, graph: any) {
        if (!graph.category) {
          return false;
        }

        const catIdStr = graph.category._id.toString(); // Safe string key
        const countryIdStr = graph.country._id.toString(); // Safe string key

        return (
          role.categories[catIdStr] &&
          role.categories[catIdStr].countries[countryIdStr] &&
          role.categories[catIdStr].countries[countryIdStr][graph.mediaType]
        );
      }

      function getStartYearForGraph(graph: any, roles: any[]) {
        let id = graph.category._id.toString(); // Single toString
        let validCategories = roles
          .map((role: any) => role.categories)
          .map((category: any) => category[id])
          .filter((cat: any) => cat)
          .map((cat: any) => new Date(String(cat.fromYear)).getTime()); // String coerce
        return new Date(Math.min(...validCategories));
      }

      function getEndYearForGraph(graph: any, roles: any[]) {
        let id = graph.category._id.toString(); // Single toString
        let validCategories = roles
          .map((role: any) => role.categories)
          .map((category: any) => category[id])
          .filter((cat: any) => cat)
          .map((cat: any) => new Date(String(cat.toYear)).getTime()); // String coerce
        return new Date(Math.max(...validCategories));
      }

      // No redeclaration – use parameter directly (typed as any[])
      graphs = graphs.map((graph: any) => {
        if (!graph.category) {
          return graph;
        }
        let start = getStartYearForGraph(graph, roles);
        let end = getEndYearForGraph(graph, roles);

        if (graph.pies) {
          graph.pies = graph.pies.filter((pie: any) => {
            if (
              new Date(String(pie.label)) < start ||
              new Date(String(pie.label)) > end
            ) {
              // String coerce
              return false;
            } else {
              return true;
            }
          });
        } else if (graph.xValues) {
          let bars: any[] = [];
          graph.xValues = graph.xValues.filter((xValue: any, i: number) => {
            if (
              new Date(String(xValue)) < start ||
              new Date(String(xValue)) > end
            ) {
              // String coerce
              graph.bars = graph.bars.map((bar: any) => {
                bar.yValues[i] = null;
                return bar;
              });
              return false;
            } else {
              return true;
            }
          });

          graph.bars = graph.bars.map((bar: any) => {
            bar.yValues = bar.yValues.filter(
              (y: any) => y !== undefined && y !== null
            );
            return bar;
          });
        }
        return graph;
      });

      graphs = graphs.map((graph: any) => {
        let exportable = false;
        roles.forEach((role: any) => {
          // forEach for side effects
          if (
            role.categories[graph.category._id.toString()] && // Safe string
            role.categories[graph.category._id.toString()].isExportable
          ) {
            exportable = true;
          }
        });

        graph.exportable = exportable;
        graph.set("exportable", exportable);
        return graph;
      });
      return graphs.filter((graph: any) =>
        roles.some((role: any) => checkGraphWithRole(role, graph))
      );
    });
}

export class GraphService {
  public saveCategory(req: Request, res: Response) {
    let category = new Categories(req.body);

    category.save((error: Error, cat: Document) => {
      if (error) {
        res.status(400).send(error);
      }

      res.json(cat);
    });
  }

  public getCategories(req: Request, res: Response) {
    Categories.find()
      .populate("headCategory")
      .then((response: any[]) => {
        res.json(response);
      })
      .catch((err: any) => {
        res.status(500).send(err);
      });
  }

  public saveHeadCategory(req: Request, res: Response) {
    let category = new HeadCategories(req.body);
    category.save((error: Error, cat: Document) => {
      if (error) {
        res.status(400).send(error);
      }
      res.json(cat);
    });
  }

  public deleteHeadCategory(req: Request, res: Response) {
    HeadCategories.deleteOne({ _id: req.query.id }).then((re: any) => {
      res.json(re);
    });
  }

  public deleteTopHeadCategory(req: Request, res: Response) {
    TopHeadCategories.deleteOne({ _id: req.query.id }).then((re: any) => {
      res.json(re);
    });
  }

  public updateHeadCategory(req: Request, res: Response) {
    let update = JSON.parse(JSON.stringify(req.body));
    delete update._id;
    HeadCategories.update(
      { _id: req.body._id },
      update,
      {},
      (err: any, doc: any) => {
        if (!err) {
          res.json(doc);
        } else {
          throw new Error(err.message || err.toString());
        }
      }
    );
  }

  public getHeadCategories(req: Request, res: Response) {
    HeadCategories.find()
      .then((response: any[]) => {
        res.json(response);
      })
      .catch((err: any) => {
        res.status(500).send(err);
      });
  }

  public saveTopHeadCategory(req: Request, res: Response) {
    let category = new TopHeadCategories(req.body);
    category.save((error: Error, cat: Document) => {
      if (error) {
        res.status(400).send(error);
      }
      res.json(cat);
    });
  }

  public updateTopHeadCategory(req: Request, res: Response) {
    let update = JSON.parse(JSON.stringify(req.body));
    delete update._id;
    TopHeadCategories.update(
      { _id: req.body._id },
      update,
      {},
      (err: any, doc: any) => {
        if (!err) {
          res.json(doc);
        } else {
          throw new Error(err.message || err.toString());
        }
      }
    );
  }

  public getTopHeadCategories(req: Request, res: Response) {
    TopHeadCategories.find()
      .then((response: any[]) => {
        res.json(response);
      })
      .catch((err: any) => {
        res.status(500).send(err);
      });
  }

  public getCountries(req: Request, res: Response) {
    Countries.find()
      .then((response: any[]) => {
        res.json(response);
      })
      .catch((err: any) => {
        res.status(500).send(err);
      });
  }

  public updateCategory(req: Request, res: Response) {
    let update = JSON.parse(JSON.stringify(req.body));
    delete update._id;
    Categories.update(
      { _id: req.body._id },
      update,
      {},
      (err: any, doc: any) => {
        if (!err) {
          res.json(doc);
        } else {
          throw new Error(err.message || err.toString());
        }
      }
    );
  }

  public deleteCategory(req: Request, res: Response) {
    let id = req.query.id;

    Categories.deleteOne({ _id: id }, (err: any) => {
      if (!err) {
        BarGraph.find({ category: id })
          .populate("category country")
          .lean()
          .then((res: any[]) => {
            res
              .filter((r: any) => !r.category)
              .forEach((bar: any) => {
                // forEach for side effects
                BarGraph.deleteOne({ _id: bar._id }).then((re: any) => {
                  console.log(re);
                });
                console.log(bar);
              });
          });

        PieGraph.find({ category: id })
          .populate("category country")
          .lean()
          .then((res: any[]) => {
            res
              .filter((r: any) => !r.category)
              .forEach((bar: any) => {
                // forEach
                PieGraph.deleteOne({ _id: bar._id }).then((re: any) => {
                  console.log(re);
                });
                console.log(bar);
              });
          });

        res.json({ success: true });
      } else {
        throw new Error(err.message || err.toString());
      }
    });
  }

  public doIt() {
    // BarGraph.find({}).populate("category country").lean().then((res) => {
    //   res.filter((r) => !r.category).map((bar) => {
    //     BarGraph.deleteOne({"_id":bar._id}).then((re) => {
    //         console.log(re)
    //       })
    //       console.log(bar)
    //   })
    // })
  }

  public updateCountry(req: Request, res: Response) {
    let update = JSON.parse(JSON.stringify(req.body));
    delete update._id;
    Countries.update(
      { _id: req.body._id },
      update,
      {},
      (err: any, doc: any) => {
        if (!err) {
          res.json(doc);
        } else {
          throw new Error(err.message || err.toString());
        }
      }
    );
  }

  public saveCountry(req: Request, res: Response) {
    let country = new Countries(req.body);
    country.save((error: Error, country: Document) => {
      if (error) {
        res.status(400).send(error);
      }
      res.json(country);
    });
  }

  public saveUserRole(req: Request, res: Response) {
    let userRole = new UserRole(req.body);
    userRole.save((error: Error, role: Document) => {
      if (error) {
        res.status(400).send(error);
      }
      res.json(role);
    });
  }

  public updateUserRole(req: Request, res: Response) {
    let update = JSON.parse(JSON.stringify(req.body));
    delete update._id;
    UserRole.update({ _id: req.body._id }, update, {}, (err: any, doc: any) => {
      if (!err) {
        res.json(doc);
      } else {
        throw new Error(err.message || err.toString());
      }
    });
  }

  public getUserRoles(req: Request, res: Response) {
    UserRole.find()
      .populate("category country")
      .then((roles: any[]) => {
        res.json(roles);
      });
  }

  public getUserUserRoles(req: Request, res: Response) {
    UserUserRole.find().then((roles: any[]) => {
      res.json(roles);
    });
  }

  public saveUserUserRole(req: Request, res: Response) {
    let userRole = new UserUserRole(req.body);
    userRole.save((error: Error, role: Document) => {
      if (error) {
        res.status(400).send(error);
      }
      res.json(role);
    });
  }

  public deleteUserUserRole(req: Request, res: Response) {
    let id = req.query.id;
    UserUserRole.deleteOne({ _id: id }, (err: any) => {
      if (!err) {
        res.json({ success: true });
      } else {
        throw new Error(err.message || err.toString());
      }
    });
  }

  public deleteUserRole(req: Request, res: Response) {
    let id = req.query.id;
    UserRole.deleteOne({ _id: id }, (err: any) => {
      if (!err) {
        res.json({ success: true });
      } else {
        throw new Error(err.message || err.toString());
      }
    });
  }

  public getCategoriesForMediaType(req: any, res: Response) {
    let mediaType = req.query.mediaType;

    let promises = [];
    promises.push(
      BarGraph.find({ mediaType: mediaType }).populate(
        "category country headCategory"
      )
    );
    promises.push(
      PieGraph.find({ mediaType: mediaType }).populate(
        "category country headCategory"
      )
    );
    promises.push(
      WaterfallGraph.find({ mediaType: mediaType }).populate(
        "category country headCategory"
      )
    );

    let that = this;
    Promise.all(promises)
      .then((graphs: any[]) => {
        let graphList = graphs.reduce(function (a: any[], b: any[]) {
          return a.concat(b);
        }, []);

        return authorizeGraphs(
          graphList,
          req.user["https://mediavision.se/roles"]
        );
      })
      .then((graphList: any[]) => {
        let categories = graphList.map((graph: any) => {
          return graph.get("category");
        });

        categories = categories.filter((category: any) => category);
        categories = categories.filter((obj: any, pos: number, arr: any[]) => {
          return (
            arr.map((mapObj: any) => mapObj["_id"]).indexOf(obj["_id"]) === pos
          );
        });

        res.json({ categories });
      });
  }

  public async getMediaTypes(req: any, res: Response) {
    let types = ["overview", "access", "sound", "text", "video"];

    let winTypes: string[] = [];

    for (let type in types) {
      let mediaType = types[type];
      let barGraphs = await BarGraph.find({ mediaType: mediaType });
      let pieGraphs = await PieGraph.find({ mediaType: mediaType });
      let barSync = await authorizeGraphs(
        barGraphs,
        req.user["https://mediavision.se/roles"]
      );
      let pieSync = await authorizeGraphs(
        pieGraphs,
        req.user["https://mediavision.se/roles"]
      );

      if (pieSync.length > 0 || barSync.length > 0) {
        winTypes.push(mediaType);
      }
    }

    res.send(winTypes);
  }

  public getGraphsForCategoryAdmin(req: Request, res: Response) {
    let categoryId = req.query.categoryId;

    Categories.findById({ _id: categoryId })
      .then((category: any) => {
        if (!category) {
          throw new Error("No category found");
        }

        switch (category.get("barType")) {
          case "barGraph":
            return BarGraph.find({ category: categoryId })
              .populate("country category")
              .exec(); // Returns Promise (no cast needed)
          case "waterfallGraph":
            return WaterfallGraph.find({ category: categoryId })
              .populate("country category")
              .exec();
          case "pieGraph":
            return PieGraph.find({ category: categoryId })
              .populate("country category")
              .exec();
          default:
            return Promise.resolve([] as any[]); // Explicit Promise
        }
      })
      .then((graphs: any[]) => {
        // Inferred as any[] from .exec()
        if (!graphs) {
          graphs = [];
        }

        res.json({ graphs });
      })
      .catch((err: any) => {
        throw new Error(err.message || err.toString());
      });
  }

  public async getGraphsForCategory(req: any, res: Response) {
    let categoryId = req.query.categoryId;
    let mediaType = req.query.mediaType;

    function getQuarter(d: Date) {
      d = d || new Date();
      var m = Math.floor(d.getMonth() / 3) + 2;
      return m > 4 ? m - 4 : m;
    }

    function cleanMyTotals(arr: any[]) {
      return arr.map((x: any) => {
        x.quarter.Q2 = x.quarter.Q2 === 0 ? x.quarter.Q1 : x.quarter.Q2;
        x.quarter.Q4 = x.quarter.Q4 === 0 ? x.quarter.Q3 : x.quarter.Q4;
        let total = 0;
        let number = 0;

        if (x.quarter.Q1 !== 0) {
          total += x.quarter.Q1;
          number++;
        }

        if (x.quarter.Q2 !== 0) {
          total += x.quarter.Q2;
          number++;
        }

        if (x.quarter.Q3 !== 0) {
          total += x.quarter.Q3;
          number++;
        }

        if (x.quarter.Q4 !== 0) {
          total += x.quarter.Q4;
          number++;
        }

        x.total = total / number;

        return x;
      });
    }

    async function getTotalNumber(isIndividual: boolean) {
      //5eff258ab213030023650148 Households
      // 5eff2722b21303002365014d Antal personer

      const result = await BarGraph.find({
        category: isIndividual
          ? "5eff2722b21303002365014d"
          : "5eff258ab213030023650148",
        mediaType: "overview",
      }).populate("country category");

      let SE: any[] = [];
      let DK: any[] = [];
      let FI: any[] = [];
      let NO: any[] = [];

      result.forEach((graph: any) => {
        // forEach for side effects
        const arr: any[] = [];
        const population = (graph.get("bars") as any[])[0].yValues;
        const values = graph
          .get("xValues")
          .map((x: any) => new Date(String(x))) // String coerce
          .map((x: Date, i: number) => {
            return {
              date: x,
              population: population[i],
            };
          })
          .forEach((x: any) => {
            // forEach since map was unused
            const year = x.date.getFullYear();
            let obj: any = null;

            let i = arr.findIndex((obj: any) => {
              return obj.year === year;
            });

            if (i === -1) {
              obj = {
                year: year,
                total: 0,
                quarter: {
                  Q1: 0,
                  Q2: 0,
                  Q3: 0,
                  Q4: 0,
                },
              };
            } else {
              obj = arr[i];
            }

            switch (getQuarter(x.date)) {
              case 2:
                obj.quarter.Q1 = x.population;
                break;
              case 3:
                obj.quarter.Q2 = x.population;
                break;
              case 4:
                obj.quarter.Q3 = x.population;
                break;
              case 1:
                obj.quarter.Q4 = x.population;
                break;
            }

            if (i === -1) {
              arr.push(obj);
            } else {
              arr[i] = obj;
            }

            switch (graph.get("country").title) {
              case "Norway":
                NO = arr;
                break;
              case "Sweden":
                SE = arr;
                break;
              case "Denmark":
                DK = arr;
                break;
              case "Finland":
                FI = arr;
                break;
            }
          });
      });

      FI = cleanMyTotals(FI);
      DK = cleanMyTotals(DK);
      SE = cleanMyTotals(SE);
      NO = cleanMyTotals(NO);

      return {
        SE,
        FI,
        DK,
        NO,
      };
    }

    let cat = null;

    Categories.findById({ _id: categoryId })
      .then((category: any) => {
        if (!category) {
          throw new Error("No category found");
        }

        cat = category;

        switch (category.get("barType")) {
          case "barGraph":
            return BarGraph.find({
              category: categoryId,
              mediaType: mediaType,
            })
              .populate("country category")
              .exec(); // Add .exec() for Promise
          case "waterfallGraph":
            return WaterfallGraph.find({
              category: categoryId,
              mediaType: mediaType,
            })
              .populate("country category")
              .exec();
          case "pieGraph":
            return PieGraph.find({
              category: categoryId,
              mediaType: mediaType,
            })
              .populate("country category")
              .exec();
          default:
            return Promise.resolve([] as any[]);
        }
      })
      .then((graphs: any[]) => {
        // Inferred from .exec()
        return authorizeGraphs(
          graphs,
          req.user["https://mediavision.se/roles"]
        );
      })
      .then(async (graphs: any[]) => {
        if (!graphs) {
          graphs = [];
        }

        let countries: { [key: string]: any } = {}; // Object with index

        graphs.forEach((graph: any) => {
          // forEach for side effects
          let country = graph.get("country");

          let countryId = country.id ? country.id.toString() : ""; // Safe toString
          if (!countries[countryId]) {
            var obj: any = {
              title: country.title,
              _id: countryId,
            };

            countries[countryId] = obj;
          }
        });

        //if(cat.get("absRel")){
        const totalNumbers = await getTotalNumber(cat.get("individual"));

        graphs = graphs.map((graph: any) => {
          graph = JSON.parse(JSON.stringify(graph));
          graph.populationData = totalNumbers;
          return graph;
        });
        //}

        res.json({ graphs, countries: Object.values(countries) }); // Convert to array
      })
      .catch((err: any) => {
        throw new Error(err.message || err.toString());
      });
  }
}
