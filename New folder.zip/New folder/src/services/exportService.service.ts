import { Request, Response } from "express";
import { Document, Types } from "mongoose";
import XLSX from "xlsx";

import {
  BarGraph,
  Categories,
  Countries,
  UserRole,
  PieGraph,
  WaterfallGraph,
} from "../models/graph.model";
import {
  excelToBarGraph,
  excelToPieGraph,
  excelToWaterfallGraph,
} from "../utils/excelConverter";

export class ExportService {
  public async exportBarGraph(req: Request, res: Response) {
    const ids = req.body.ids;
    const startYear = new Date(req.body.startYear);
    const endYear = new Date(req.body.endYear);
    var graphs = await BarGraph.find({
      _id: { $in: [ids.map((id) => new Types.ObjectId(id))] },
    })
      .populate("country category")
      .lean();

    graphs = graphs.map((graph) => {
      console.log(startYear, endYear);
      if (!req.body.startYear || !req.body.endYear) {
        return graph;
      }

      console.log("wowwww");

      if (graph.xType === "year" || graph.xType === "quarter") {
        // let datesToRemove = []

        // graph.xValues.map((xValue, index)  => {
        //     let date = new Date(xValue)
        //     if( date > endYear || startYear > date){
        //         datesToRemove.push(index)
        //     }
        // })

        // console.log(datesToRemove)
        // datesToRemove.map((dateToRemove) => {
        //     graph.xValues.splice(dateToRemove, 1)
        //     graph.bars.splice(dateToRemove, 1)
        // })

        return graph;
      }

      return graph;
    });

    res.json(graphs);
  }
}
