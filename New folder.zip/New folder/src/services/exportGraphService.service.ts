// Require library
import { Exported } from '../models/graph.model'
let excel = require('excel4node');
let fs = require('file-system');
const sgMail = require('@sendgrid/mail');
sgMail.setApiKey("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");

export function exportExcel(req,res){
    Exported.create({email:req.user.sub, category:req.body.map((x) => x.title).join(" ") })
    sgMail.send({
        to        : 'gunnar.klofver@mediavision.se',
        from      : 'support@mediavision.se',
        subject   : 'New download',
        html: "<p>User id: " + req.user.sub + " </p><p>Category: " + req.body.map((x) => x.title).join(" ") + "</p>"
    })

    let sheets = req.body
    let isPercent = req.query.isPercent === "true" ? true : false
    

    var workbook = new excel.Workbook();
    var styleDate = workbook.createStyle({
        font: {
            size: 12,
            name:"Avenir Next LT Pro"
        },
    });

    var styleTitle = workbook.createStyle({
        font: {
            size: 28,
            name:"Avenir Next LT Pro",
            bold:true
        },
    });

    var styleCopyright = workbook.createStyle({
        font: {
            size: 14,
            name:"Avenir Next LT Pro",
            
        },
    });

    var worksheet = workbook.addWorksheet("Confidentiality note");
    var todayDate = new Date().toISOString().slice(0,10);


    worksheet.cell(2,2).string(todayDate).style(styleDate);
    worksheet.cell(3,2).string("Confidentiality notice").style(workbook.createStyle({
        font: {
            size: 24,
            name:"Avenir Next LT Pro"
        },
    }));
    worksheet.cell(5,2).string("FOR INTERNAL USE ONLY").style(styleTitle);
    worksheet.cell(7,2).string("© Mediavision AB 2021").style(styleCopyright)
    worksheet.cell(9,2).string("All rights reserved. This publication is protected by copyright.").style(workbook.createStyle({
        font: {
            size: 11,
            name:"Avenir Next LT Pro",
            italic:true
            
        },
    }))
    worksheet.cell(10,2).string("This document was prepared exclusively for the benefit and internal use of your company in order to indicate, on a preliminary basis, a possible market development. It does not carry any right of publication or disclosure to any other party. This document may not be used for any other purpose without the prior written consent of Mediavision. The information reflects prevailing conditions and our views as of this date, all of which are accordingly subject to change.").style(workbook.createStyle({
        font: {
            size: 11,
            name:"Avenir Next LT Pro",
            
        },
        alignment: {
            wrapText:true
        }
    }))
    worksheet.column(2).setWidth(50)
    worksheet.row(10).setHeight(135)

    sheets.map((sheet) => {
        var worksheet = workbook.addWorksheet(sheet.name);
        var style = workbook.createStyle({
            font: {
                size: 14,
                name:"Avenir Next LT Pro"
            },
            numberFormat: isPercent ?  '#%; -#%; -' : null
        });

        var titleStyle = workbook.createStyle({
            font: {
                size: 16,
                name:"Avenir Next LT Pro"
            }
        });

        var subTitleStyle = workbook.createStyle({
            font: {
                size: 14,
                name:"Avenir Next LT Pro"
            }
        });

        worksheet.cell(1,1).string(sheet.title).style(titleStyle)
        worksheet.cell(2,1).string(sheet.subTitle).style(subTitleStyle)

        sheet.data.map((rowData,row) => {
            rowData.map((columnData,col) => {
                if(typeof(columnData) === "string"){
                    worksheet.cell(row + 4,col + 1).string(columnData).style(style);
                } else if (typeof(columnData) === "number"){
                    worksheet.cell(row + 4,col + 1).number(isPercent ? Math.round(columnData*100)/100 : Math.round(columnData)).style(style);
                } 
            })
        })
    })    

    
    workbook.writeToBuffer().then(function(buffer) {
        // Do something with buffer
        var todayDate = new Date().toISOString().slice(0,10);

        
        sgMail.send({
            to        : req.query.email,
            from      : 'support@mediavision.se',
            subject   : 'Mediavision Instant Insights data export',
    
            attachments     : [{filename: 'MII_export_' + todayDate +".xlsx", content: Buffer.from(buffer).toString('base64'), type:"application/xlsx"}],
            html: "<p>Enclosed is the MII Data you requested to be exported.</p> <p>Please note that it is a personal copy, strictly to be used for purposes within you company  and not to be distributed further.</p><p>It does not carry any right of publication or disclosure to any other party. This document cannot be forwarded, nor used for any other purpose without the prior written consent of Mediavision.</p><p>The information reflects prevailing conditions and our views as of this date, all of which are accordingly subject to change.</p>"
        }).then((a)=> {
            res.send(req.user)
        })
    });
}
