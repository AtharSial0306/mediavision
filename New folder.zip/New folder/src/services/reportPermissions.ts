import { Request, Response } from "express";
import { Report, Users } from "../models/graph.model";
import axios from "axios";
// var request = require("request");

const ExcelJS = require("exceljs");

interface MulterRequest extends Request {
  file: any;
}

var path = require("path");
const multer = require("multer");

export class ReportPermissions {
  public async updatePermissions(req: MulterRequest, res: Response) {
    const stuff: any = req;
    const somePath = req.file.path;
    const data = await parseXLSFile(somePath);
    if (data.status === "done") {
      await updateUsersWithAuth0(stuff.user.sub);
    }
    await createPermissionsFile();

    res.json(data);
  }
}

const updateUsersWithAuth0 = async (userSub) => {
  let auth0Token = null;
  let currentUser = null;

  const data = `{
        "client_id":"${process.env.AUTH0_CLIENT_ID}",
        "client_secret":"${process.env.AUTH0_SECRET}",
        "audience":"https://mediavision.eu.auth0.com/api/v2/",
        "grant_type":"client_credentials"
        }`;

  const headers1 = { headers: { "content-type": "application/json" } };
  await axios
    .post("https://mediavision.eu.auth0.com/oauth/token", data, headers1)
    .then((resp) => {
      return (auth0Token = resp && resp.data ? resp.data.access_token : null);
    })
    .catch((e) => {
      console.log("err", e);
    });

  const headers2 = {
    headers: {
      "content-type": "application/json",
      accept: "application/json",
      Authorization: "Bearer " + auth0Token,
    },
  };
  const data2 = JSON.stringify({
    app_metadata: {
      has_accept: true,
    },
  });

  await axios
    .patch(
      `https://mediavision.eu.auth0.com/api/v2/users/${userSub}`,
      data2,
      headers2
    )
    .then((resp2) => {
      currentUser = resp2.data;
    });

  let userAuthKeys = [];
  const insightsUsers: any = await Users.find({});
  await axios
    .get(
      "https://mediavision.eu.auth0.com/api/v2/users?q=name:*&search_engine:v3",
      headers2
    )
    .then(async (resp3) => {
      for (let authUser of resp3.data) {
        const matchedUser = insightsUsers.find((insightsUser) => {
          return insightsUser.email === authUser.email;
        });

        if (matchedUser) {
          userAuthKeys.push({
            email: authUser.email,
            auth_key: authUser.user_id,
          });

          await Users.updateOne(
            { email: authUser.email },
            {
              $set: {
                auth_key: authUser.user_id,
              },
            }
          );
        }
      }
    });
};

const parseXLSFile = async (filepath) => {
  const workbook = new ExcelJS.Workbook();
  const users = [];
  const existingReports = await Report.find({});

  const results = workbook.xlsx
    .readFile(path.resolve(filepath))
    .then(function () {
      var worksheet = workbook.getWorksheet(workbook.getWorksheet().name);
      let reportNames = [];

      worksheet.eachRow({ includeEmpty: true }, function (row, rowNumber) {
        reportNames = setReportNamesArray(
          rowNumber,
          row,
          existingReports,
          reportNames
        );

        if (rowNumber > 1) {
          let userReports = [];
          for (
            let currentColumnNo = 0;
            currentColumnNo < row.values.length;
            currentColumnNo++
          ) {
            if (currentColumnNo > 3) {
              if (row.values[currentColumnNo]) {
                if (reportNames[currentColumnNo]) {
                  userReports.push({
                    report_id: reportNames[currentColumnNo].report_id,
                    report_name: reportNames[currentColumnNo].report_name,
                  });
                }
              }
            }
          }

          if (row.values[1] && row.values[2]) {
            users.push({
              name: row.values[1],
              email: row.values[2],
              company: row.values[3],
              report_access: userReports,
            });
          }
        }
      });

      return { status: "done" };
    })
    .then(async (resp) => {
      await saveUsers(users);
      return resp;
    });

  return results;
};

const setReportNamesArray = (rowNumber, row, existingReports, reportNames) => {
  if (rowNumber === 1) {
    for (
      let reportNameIndex = 1;
      reportNameIndex < row.values.length;
      reportNameIndex++
    ) {
      if (row.values[reportNameIndex]) {
        const currentReportObj = existingReports.find((rep) => {
          return rep.report_name === row.values[reportNameIndex];
        });

        if (currentReportObj) {
          reportNames[reportNameIndex] = {
            report_id: currentReportObj._id,
            report_name: currentReportObj.report_name,
          };
        }
      }
    }
  }

  return reportNames;
};

const saveUsers = async (users) => {
  await Users.deleteMany({});
  await Users.insertMany(users);
};

export const createPermissionsFile = async () => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("Permissions");
  const allReports: any = await Report.find({});
  const allUsers: any = await Users.find({});

  let columns = [
    { header: "Customer", key: "customer", width: 10 },
    { header: "Mail", key: "mail", width: 32 },
    { header: "Company", key: "company", width: 10, outlineLevel: 1 },
  ];
  for (let report of allReports) {
    if (report.report_name) {
      columns.push({
        header: report.report_name,
        key: report.report_name,
        width: 32,
      });
    }
  }

  worksheet.columns = columns;

  for (let user of allUsers) {
    let rowValues = {
      customer: user.name,
      mail: user.email,
      company: user.company,
    };

    for (let report of allReports) {
      if (report.report_name) {
        const userHasAccessToReport = user.report_access.find((userReport) => {
          return userReport.report_id === report._id.toString();
        });

        rowValues[report.report_name] = userHasAccessToReport ? 1 : "";
      }
    }
    worksheet.addRow(rowValues);
  }

  await workbook.csv.writeBuffer();
  await workbook.xlsx.writeFile("uploads/User-permissions.xlsx");

  return true;
};
