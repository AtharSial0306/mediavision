import mongoose, { mongo } from "mongoose";

const StreamingSchema = new mongoose.Schema({
  title: String,
  description: String,
  roles: [String],
  URL: String,
  date: String,
});

const BarGraphSchema = new mongoose.Schema({
  title: String,
  xLabel: String,
  xValues: [mongoose.Schema.Types.Mixed],
  xType: String,
  yLabel: String,
  bars: [{ label: String, yValues: [] }],
  category: { type: mongoose.Schema.Types.ObjectId, ref: "Category" },
  country: { type: mongoose.Schema.Types.ObjectId, ref: "Country" },
  mediaType: String,
  hasDecimals: Number,
  isPercentage: Boolean,
  exportable: Boolean,
  yType: { type: String, default: "" },
});

const PieGraphSchema = new mongoose.Schema({
  title: String,
  hasDecimals: Number,
  categoryLabel: String,
  pies: [{ label: String, pie: { type: Map, of: Number } }],
  category: { type: mongoose.Schema.Types.ObjectId, ref: "Category" },
  country: { type: mongoose.Schema.Types.ObjectId, ref: "Country" },
  mediaType: String,
  xType: String,
  exportable: Boolean,
});

const WaterfallGraphSchema = new mongoose.Schema({
  title: String,
  seqLabels: [String],
  xLabel: String,
  xValues: [mongoose.Schema.Types.Mixed],
  sequences: [[Number]],
  category: { type: mongoose.Schema.Types.ObjectId, ref: "Category" },
  country: { type: mongoose.Schema.Types.ObjectId, ref: "Country" },
  mediaType: String,
});

const CategorySchema = new mongoose.Schema({
  title: String,
  barType: String,
  footnote: String,
  subtitle: String,
  showCombined: Boolean,
  showCombinedAlternative: Boolean,
  order: Number,
  absRel: Boolean,
  individual: Boolean,
  headCategory: { type: mongoose.Schema.Types.ObjectId, ref: "HeadCategory" },
});

const HeadCategorySchema = new mongoose.Schema({
  title: String,
  order: Number,
  topHeadCategory: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "TopHeadCategory",
  },
});

const TopHeadCategorySchema = new mongoose.Schema({
  title: String,
  order: Number,
});

const ReportSchema = new mongoose.Schema(
  {
    report_name: { type: String, required: true, unique: true },
    report_group: { type: String, required: true },
    publishing_date: Date,
    period: String,
    file_path: String,
    file_name: String,
    file: String,
  },
  { strict: true }
);

const UserSchema = new mongoose.Schema(
  {
    name: String,
    email: { type: String, unique: true, required: true },
    auth_id: String,
    company: String,
    accessDashboard: {
      type: Boolean,
      default: false,
    },
    accessAnalytics: {
      type: Boolean,
      default: false,
    },
    report_access: [
      {
        report_id: { type: String },
        report_name: { type: String },
      },
    ],
    auth_key: String,
  },
  { strict: true }
);

const CountrySchema = new mongoose.Schema({
  title: String,
});

const UserRoleSchema = new mongoose.Schema({
  title: String,
  updated: String,
  countrySet: String,
  premiumUpdated: String,
  visible: Boolean,
  categories: [
    {
      fromYear: String,
      toYear: String,
      isExportable: Boolean,
      category: { type: mongoose.Schema.Types.ObjectId, ref: "Category" },
      countries: [
        {
          country: { type: mongoose.Schema.Types.ObjectId, ref: "Country" },
          video: Boolean,
          text: Boolean,
          sound: Boolean,
          overview: Boolean,
          access: Boolean,
        },
      ],
    },
  ],
});

const UserUserRoleSchema = new mongoose.Schema({
  userId: String,
  role: { type: mongoose.Schema.Types.ObjectId, ref: "UserRole" },
});

const ExportedSchema = new mongoose.Schema({
  email: String,
  category: String,
});

export const Streaming = mongoose.model("Streaming", StreamingSchema);

export const BarGraph = mongoose.model("BarGraph", BarGraphSchema);
export const PieGraph = mongoose.model("PieGraph", PieGraphSchema);
export const WaterfallGraph = mongoose.model(
  "WaterfallGraph",
  WaterfallGraphSchema
);

export const Categories = mongoose.model("Category", CategorySchema);
export const HeadCategories = mongoose.model(
  "HeadCategory",
  HeadCategorySchema
);
export const TopHeadCategories = mongoose.model(
  "TopHeadCategory",
  TopHeadCategorySchema
);

export const Countries = mongoose.model("Country", CountrySchema);
export const UserRole = mongoose.model("UserRole", UserRoleSchema);
export const Exported = mongoose.model("Exported", ExportedSchema);
export const UserUserRole = mongoose.model("UserUserRole", UserRoleSchema);
export const Report = mongoose.model("Report", ReportSchema);
export const Users = mongoose.model("Users", UserSchema);
