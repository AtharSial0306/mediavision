import { Application, Request, Response } from "express";
import { GraphStorage } from "./services/graphStorage.service";
import { GraphService } from "./services/graphService.service";
import { ReportsService } from "./services/reportsService";
import { StreamingClass } from "./services/streamingService";

import { exportExcel } from "./services/exportGraphService.service";
import { categoryValidator } from "./validators/categoryValidator";
import { barValidator } from "./validators/barValidator";
import { pieValidator } from "./validators/pieValidator";
import { ReportPermissions } from "./services/reportPermissions";
import * as path from "path";
import { reportValidator } from "./validators/reportValidator";
const multer = require("multer");
const jwtAuthz = require("express-jwt-authz");

const adminScope = jwtAuthz(["admin"]);
var request = require("request");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.resolve("uploads"));
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});
const upload = multer({ storage: storage });

export class Controller {
  private graphStorage: GraphStorage;
  private graphService: GraphService;
  private streamingService: StreamingClass;
  private reportService: ReportsService;
  private reportPermissions: ReportPermissions;

  constructor(private app: Application) {
    this.graphStorage = new GraphStorage();
    this.graphService = new GraphService();
    this.streamingService = new StreamingClass();
    this.reportService = new ReportsService();
    this.reportPermissions = new ReportPermissions();
    this.routes();
  }

  public routes() {
    // The streaming stuff

    this.app.route("/testroute").get(this.streamingService.myRoute);

    this.app
      .route("/streaming/create")
      .post(this.streamingService.createStreaming);
    this.app
      .route("/streaming/update")
      .post(this.streamingService.updateStreaming);
    this.app.route("/streaming/").get(this.streamingService.getStreaming);
    this.app
      .route("/streaming/admin")
      .get(this.streamingService.getStreamingAdmin);
    this.app.route("/streaming/single").get(this.streamingService.getStream);
    this.app
      .route("/streaming/single")
      .delete(this.streamingService.deleteStream);

    // The graph stuff

    this.app
      .route("/graphs/bar")
      .post(adminScope, barValidator, this.graphStorage.saveBarGraph);
    this.app
      .route("/graphs/bar")
      .delete(adminScope, this.graphStorage.deleteBarGraph);
    this.app
      .route("/graphs/bar")
      .put(adminScope, this.graphStorage.updateBarData);

    this.app
      .route("/graphs/pie")
      .post(adminScope, pieValidator, this.graphStorage.savePieGraph);
    this.app
      .route("/graphs/pie")
      .delete(adminScope, this.graphStorage.deletePieGraph);

    this.app
      .route("/graphs/waterfall")
      .post(this.graphStorage.saveWaterfallGraph);
    this.app
      .route("/graphs/waterfall")
      .delete(this.graphStorage.deleteWaterFallGraph);

    //this.app.route('/export/waterfall').post( this.graphStorage.saveWaterfallGraph);
    //this.app.route('/export/pie').post( this.graphStorage.saveWaterfallGraph);

    this.app
      .route("/graphforcategory")
      .get(this.graphService.getGraphsForCategory);
    this.app
      .route("/admin/graphforcategory")
      .get(this.graphService.getGraphsForCategoryAdmin);
    this.app.route("/mediatypes").get(this.graphService.getMediaTypes);

    this.app
      .route("/categoriesformediatype")
      .get(this.graphService.getCategoriesForMediaType);
    this.app
      .route("/admin/updateBulk")
      .post(adminScope, this.graphStorage.updateBulk);
    this.app
      .route("/admin/downloadBulk")
      .post(adminScope, this.graphStorage.downloadBulk);

    // The admin side of stuff
    this.app
      .route("/categories")
      .post(adminScope, categoryValidator, this.graphService.saveCategory);
    this.app
      .route("/categories")
      .get(adminScope, this.graphService.getCategories);
    this.app
      .route("/categories")
      .put(adminScope, categoryValidator, this.graphService.updateCategory);
    this.app
      .route("/categories")
      .delete(adminScope, this.graphService.deleteCategory);

    this.app
      .route("/headcategories")
      .post(adminScope, this.graphService.saveHeadCategory);
    this.app.route("/headcategories").get(this.graphService.getHeadCategories);
    this.app
      .route("/headcategories")
      .put(adminScope, this.graphService.updateHeadCategory);
    this.app
      .route("/headcategories")
      .delete(adminScope, this.graphService.deleteHeadCategory);

    this.app
      .route("/topheadcategories")
      .post(adminScope, this.graphService.saveTopHeadCategory);
    this.app
      .route("/topheadcategories")
      .get(this.graphService.getTopHeadCategories);
    this.app
      .route("/topheadcategories")
      .put(adminScope, this.graphService.updateTopHeadCategory);
    this.app
      .route("/topheadcategories")
      .delete(adminScope, this.graphService.deleteTopHeadCategory);

    this.app
      .route("/countries")
      .post(adminScope, this.graphService.saveCountry); // Done
    this.app.route("/countries").get(this.graphService.getCountries); // Done
    this.app
      .route("/countries")
      .put(adminScope, this.graphService.updateCountry);

    this.app
      .route("/userrole")
      .post(adminScope, this.graphService.saveUserRole);
    this.app
      .route("/userrole")
      .put(adminScope, this.graphService.updateUserRole);
    this.app.route("/userrole").get(this.graphService.getUserRoles);
    this.app
      .route("/userrole")
      .delete(adminScope, this.graphService.deleteUserRole);

    this.app.route("/reports").get(this.reportService.getReports);
    this.app.route("/reports/:id").get(this.reportService.getUserReports);
    // this.app.route('/reports/:id').get(this.reportService.getReportFile);
    this.app
      .route("/reports")
      .post(
        upload.single("file"),
        reportValidator,
        this.reportService.createReport
      );
    this.app
      .route("/reports")
      .put(
        upload.single("file"),
        reportValidator,
        this.reportService.updateReports
      );
    this.app.route("/reports").delete(this.reportService.deleteReports);

    // this.app.route('/report-permissions').get(this.reportPermissions.getPermissions);
    this.app
      .route("/report-permissions")
      .post(upload.single("file"), this.reportPermissions.updatePermissions);
    this.app.route("/uploads/:imageName").get(this.reportService.getImage);

    this.app.route("/accept").get((req: any, res) => {
      var options = {
        method: "POST",
        url: "https://mediavision.eu.auth0.com/oauth/token",
        headers: { "content-type": "application/json" },
        body: `{
        "client_id":${process.env.AUTH0_CLIENT_ID},
        "client_secret":${process.env.AUTH0_SECRET},
        "audience":"https://mediavision.eu.auth0.com/api/v2/",
        "grant_type":"client_credentials"
        }`,
      };

      request(options, function (error, response, body) {
        if (error) throw new Error(error);
        let bodJson = JSON.parse(body);
        let url =
          "https://mediavision.eu.auth0.com/api/v2/users/" + req.user.sub;
        var options = {
          method: "PATCH",
          url: url,
          headers: {
            "content-type": "application/json",
            accept: "application/json",
            Authorization: "Bearer " + bodJson.access_token,
          },
          body: JSON.stringify({
            app_metadata: {
              has_accept: true,
            },
          }),
        };

        request(options, function (error, response, body) {
          //if (error) throw new Error(error);
          console.log(response);
          console.log(error);
          res.send({});
        });
      });
    });

    this.app.route("/change").get((req: any, res) => {
      var options = {
        method: "POST",
        url: "https://mediavision.eu.auth0.com/oauth/token",
        headers: { "content-type": "application/json" },
        body: '{"client_id":"RfwboxGfsriMEBZ52w4C3evatvq8YxAm","client_secret":"xj57CCcWADJkJ2mtNandvRWFJM7vChlcQ8YXb8f4XzUXGSmNfEU9NK07n0-ny40m","audience":"https://mediavision.eu.auth0.com/api/v2/","grant_type":"client_credentials"}',
      };

      request(options, function (error, response, body) {
        if (error) throw new Error(error);
        let bodJson = JSON.parse(body);

        let url =
          "https://mediavision.eu.auth0.com/api/v2/users/" + req.user.sub;
        var options = {
          method: "GET",
          url: url,
          headers: {
            "content-type": "application/json",
            accept: "application/json",
            Authorization: "Bearer " + bodJson.access_token,
          },
        };

        request(options, function (error, response, body) {
          //if (error) throw new Error(error);
          let bod = JSON.parse(body);

          var options = {
            method: "POST",
            url: "https://mediavision.eu.auth0.com/dbconnections/change_password",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              client_id: "RfwboxGfsriMEBZ52w4C3evatvq8YxAm",
              email: bod.email,
              connection: "Username-Password-Authentication",
            }),
          };
          request(options, function (error, response, body) {
            res.send({ body });
          });
        });
      });
    });

    this.app.route("/userrole/user").get(this.graphService.getUserUserRoles);
    this.app
      .route("/userrole/user")
      .post(adminScope, this.graphService.saveUserUserRole);
    //  this.app.route('/userrole/user').delete( this.graphService.deleteUserUserRole);

    this.graphService.doIt();
    this.app.route("/export").post(exportExcel);
  }
}
