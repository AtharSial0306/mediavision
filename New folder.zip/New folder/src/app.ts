import express, { Application } from "express";
import bodyParser from "body-parser";
import cors from "cors";
import mongoose from "mongoose";
// var jwt = require("express-jwt");
import { expressjwt } from "express-jwt";
var jwks = require("jwks-rsa");
import dotenv from "dotenv";

import { Controller } from "./main.controller";
mongoose.set("strictQuery", false);
class App {
  public app: Application;
  public controller: Controller;

  constructor() {
    this.app = express();
    this.setConfig();
    this.setMongoConfig();

    this.controller = new Controller(this.app);
  }

  private setConfig() {
    this.app.use(bodyParser.json({ limit: "50mb" }));
    this.app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));
    this.app.use(cors());

    // var jwtCheck = expressjwt({
    //   secret: jwks.expressJwtSecret({
    //     cache: true,
    //     rateLimit: true,
    //     jwksRequestsPerMinute: 5,
    //     jwksUri: "https://mediavision.eu.auth0.com/.well-known/jwks.json",
    //   }),
    //   audience: "mediavisionapp",
    //   issuer: "https://mediavision.eu.auth0.com/",
    //   algorithms: ["RS256"],
    // });

    // this.app.use(jwtCheck.unless({ path: /uploads/ }));
  }

  private setMongoConfig() {
    mongoose.Promise = global.Promise;
    mongoose
      .connect(process.env.MONGO_URL)
      .then(() => console.log(`Database Connected`))
      .catch((err) => {
        console.log(`ERROR: ${err}`);
      });
  }
}

export default new App().app;
