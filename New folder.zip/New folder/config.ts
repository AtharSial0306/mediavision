export const config: {[key: string]: {[key: string]: string}} = {
  'development': {
    'dev': 'dev',
    'dbUrl': 'mongodb://localhost:27017/Dev'
  },
  'test': {
    'config_id': 'test',
    'dbUrl': 'mongodb://localhost:27017/Test'
  },
  'prod': {
    'config_id': 'prod'
  }
};
