# Graph Storage Backend

Storing graphs defined in Excel (.xlsx) sheets using TypeScript, Node.js, Express, MongoDB and Docker. 

## Tests
Tests are found in the folder [test](test/), and run using npm: 

```bash
npm test
```

## Supported graph types

### Line

#### Expected Excel format
| graph-title  |                |                |     |                |
|--------------|----------------|----------------|-----|----------------|
| x-label      | x-label-1      | x-label-2      | ... | x-label-m      |
| line-1-label | line-1-value-1 | line-1-value-2 | ... | line-1-value-m |
| line-2-label | line-2-value-1 | line-2-value2  | ... | line-2-value-m |
| ...          | ...            | ...            | ... | ...            |
| line-n-label | line-n-value-1 | line-n-value-2 | ... | line-n-value-m |

#### Example

### Bar 

#### Expected Excel format
| **x-label**   | **bar-1-label**   | **bar-2-label**   | ... | **bar-n-label**   |
|-------------|------------------|------------------|-----|------------------|
| x-label-1 | bar-1-value-1 | bar-2-value-1 | ... | bar-n-value-1 |
| x-label-2 | bar-1-value-2 | bar-2-value-2 | ... | bar-n-value-2 |
| ...         | ...              | ...              | ... | ...              |
| x-label-m | bar-1-value-m | bar-2-value-m | ... | bar-n-value-m |

#### Example

### Pie 

#### Expected Excel format 
| **category-label**   | **percentage-label** |
|------------------|------------------|
| category-label-1 | category-1-perc  |
| category-label-2 | category-2-perc  |
| ...              | ...              |
| category-label-n | category-n-perc  |

#### Example

### Waterfall
